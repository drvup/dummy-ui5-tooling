/*!
 * OpenUI5
 * (c) Copyright 2009-2021 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/m/changeHandler/CombineButtons","sap/m/changeHandler/SplitMenuButton"],function(e,n){"use strict";return{moveControls:"default",combineButtons:{changeHandler:e,layers:{CUSTOMER:false}},splitMenuButton:{changeHandler:n,layers:{CUSTOMER:false}}}},true);