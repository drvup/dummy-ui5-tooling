/*!
 * OpenUI5
 * (c) Copyright 2009-2021 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/m/semantic/SemanticSelect"],function(e){"use strict";var a=e.extend("sap.m.semantic.GroupSelect",{metadata:{library:"sap.m",interfaces:["sap.m.semantic.IGroup"]}});return a});