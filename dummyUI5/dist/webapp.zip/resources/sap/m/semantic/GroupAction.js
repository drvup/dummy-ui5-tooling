/*!
 * OpenUI5
 * (c) Copyright 2009-2021 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/m/semantic/SemanticButton"],function(a){"use strict";var t=a.extend("sap.m.semantic.GroupAction",{metadata:{library:"sap.m",interfaces:["sap.m.semantic.IGroup"]}});return t});